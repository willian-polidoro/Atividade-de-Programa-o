package Exercicio_06;
import java.util.Scanner;

    public class SistemaLoja {
        // Método criado: mostrarcabecalho fora do main( Dica 1)
        public static void mostarcabecalho() {
            System.out.println("=== LOJA JAVA ===");
        }

        // Método criado: calcularSubtotal fora do main ( Dica 2)
        public static double calcularSubtotal(double preco, int quantidade) {
            return preco * quantidade;
        }

        // Método criado: calcular Desconto fora do main ( Dica 3 )
        public static double calcularDesconto(double subtotal) {

            if (subtotal >= 200) {
                return subtotal * 0.10;
            }
            return 0;
        }

        // Método criado: calcular Total fora do main ( Dica 4 )
        public static double calcularTotal(double subtotal, double desconto) {

            double total = subtotal - desconto;
            return total;
        }
        // Método criado: mostrar Recido fora do main ( Dica 5 )
        public static double mostrarRecibo(String cliente, String produto, int quantidade, double subtotal,
                                           double desconto, double total ) {

            System.out.println();
            System.out.println("=== RECIBO ===");
            System.out.println("Cliente: " + cliente);
            System.out.println("Produto: " + produto);
            System.out.println("Quantidade: " + quantidade);
            System.out.println("Subtotal: R$ " + subtotal);
            System.out.println("Desconto: R$ " + desconto);
            System.out.println("Total: R$ " + total);
            return 0;
        }
        // Método criado: realizar Venda fora do main ( Dica 6 )

        public static void realizarvenda(Scanner sc){
            mostarcabecalho();
            System.out.print("Nome do cliente: ");
            String cliente = sc.nextLine();
            System.out.print("Nome do produto: ");
            String produto = sc.nextLine();
            System.out.print("Preço unitário: ");
            double preco = sc.nextDouble();
            System.out.print("Quantidade: ");
            int quantidade = sc.nextInt();
            double subtotal= calcularSubtotal(preco,quantidade);
            double desconto= calcularDesconto(subtotal);
            double total = calcularTotal(subtotal, desconto);
            mostrarRecibo(cliente, produto, quantidade, subtotal, desconto, total);
        }

            public static void main(String[] args) {
                Scanner sc = new Scanner(System.in);
                String continuar = "s";

                while (continuar.equalsIgnoreCase("s")){
                    realizarvenda(sc);
                    System.out.print("Deseja realizar outra venda!  (s/n) :");
                    continuar = sc.next();
                }

                sc.close();
            }
        }
