package Exercicio_03;

public class Main {
    public static void main(String[] args) {
        mostrarDobro(8);
        mostrarSoma(10, 5);

    }
    // Método criado:
    public static void mostrarDobro(int numero) {
        System.out.println("O dobro é " + numero * 2 + ":");
    }

    // Método criado:
    public static void mostrarSoma(int a, int b) {
        int soma = a+b;
        System.out.println("A Soma é " + soma + ":");
 if( a > b) {
     System.out.println(a + " é maior que " + b);
 }else{
     System.out.println(a + " é menor que " +b );
 }
    }

}
