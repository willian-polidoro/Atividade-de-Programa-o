package Exercicio_07;

import java.util.Scanner;

    // Método criado:
    public class SistemaVendas {
    public static void sistemaDeVendas() {
        System.out.println("\n=== SISTEMA DE VENDAS ===");
        System.out.println("1 - Nova venda");
        System.out.println("2 - Encerrar");
        System.out.print("Escolha: ");

    }

    // Método criado:
    public static double mostrarComprovante(String cliente, String produto,
                                            int quantidade,
                                            double subtotal,
                                            double desconto, double descontoVip,
                                            double descontoPix, double total) {
        System.out.println("\n===== COMPROVANTE =====");
        System.out.println("Cliente: " + cliente);
        System.out.println("Produto: " + produto);
        System.out.println("Quantidade: " + quantidade);
        System.out.println("Subtotal: R$ " + subtotal);
        System.out.println("Desconto: R$ " + desconto);
        System.out.println("Desconto VIP: R$ " + descontoVip);
        System.out.println("Desconto PIX: R$ " + descontoPix);
        System.out.println("Total: R$ " + total);
        return 1;
    }

    // Método criado:
    public static double comprovante(int totalVendas, int totalProdutos,
                                     double faturamento,
                                     double totalDescontos, double maiorVenda,
                                     String clienteMaiorVenda) {
        System.out.println("\n===== RELATÓRIO FINAL =====");
        System.out.println("Total de vendas: " + totalVendas);
        System.out.println("Produtos vendidos: " + totalProdutos);
        System.out.println("Faturamento: R$ " + faturamento);
        System.out.println("Descontos: R$ " + totalDescontos);
        System.out.println("Maior venda: R$ " + maiorVenda);
        System.out.println("Cliente: " + clienteMaiorVenda);
        return 0;

    }
    // Método criado:
    public static void mostrarOpcoes(int totalVendas, int totalProdutos,
                                     double faturamento,
                                     double totalDescontos, double maiorVenda,
                                     String clienteMaiorVenda) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nome do cliente: ");
        String cliente = sc.nextLine();
        System.out.print("Nome do produto: ");
        String produto = sc.nextLine();
        System.out.print("Preço unitário: ");
        double preco = sc.nextDouble();
        System.out.print("Quantidade: ");
        int quantidade = sc.nextInt();
        System.out.print("Cliente VIP (1-Sim / 2-Não): ");
        int vip = sc.nextInt();
        System.out.println("Pagamento por PIX (1-Sim / 2-Não): ?");
        int pix = sc.nextInt();

        if (preco <= 0 || quantidade <= 0) {
            System.out.println("Dados inválidos!");

        }

        double subtotal = preco * quantidade;
        double desconto = 0;
        if (subtotal >= 500) {
            desconto = subtotal * 0.15;
        } else if (subtotal >= 200) {
            desconto = subtotal * 0.10;
        } else if (subtotal >= 100) {
            desconto = subtotal * 0.05;
        }

        double descontoVip = 0;
        if (vip == 1) {
            descontoVip = subtotal * 0.05;
        }

        double descontoPix = 0;
        if (pix == 1) {
            descontoPix = subtotal * 0.03;

        }

        double total = subtotal - desconto - descontoVip - descontoPix;

        totalVendas++;
        totalProdutos += quantidade;
        faturamento += total;
        totalDescontos += desconto + descontoVip + descontoPix;

        if (total > maiorVenda) {
            maiorVenda = total;
            clienteMaiorVenda = cliente;

            mostrarComprovante(cliente, produto, quantidade, subtotal,
                    desconto, descontoVip,
                    descontoPix, total);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sistemaDeVendas();
        int opcao = 0;
        int totalVendas = 0;
        int totalProdutos = 0;
        double faturamento = 0;
        double totalDescontos = 0;
        double maiorVenda = 0;
        String clienteMaiorVenda = "";

        while (opcao != 2) {

            opcao = sc.nextInt();
            sc.nextLine();

            if (opcao == 1) {

                mostrarOpcoes(totalVendas, totalProdutos, faturamento,
                        totalDescontos, maiorVenda, clienteMaiorVenda);

            } else if (opcao != 2) {
                System.out.println("Opção inválida!");
            }
        }

        comprovante(totalVendas, totalProdutos, faturamento,
                totalDescontos, maiorVenda, clienteMaiorVenda);
        if (totalVendas > 0) {
            double ticketMedio = faturamento / totalVendas;
            System.out.println("Ticket médio: R$ " + ticketMedio);

            sc.close();
        }
    }
}