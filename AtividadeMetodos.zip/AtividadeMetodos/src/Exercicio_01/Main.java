package Exercicio_01;

public class Main {

      // Método criado:
    public static void mostrarBoasVindas() {


        System.out.println("Bem-vindo ao mundo Java!.");
    }
    public static void main(String[] args) {
        mostrarBoasVindas();
        mostrarBoasVindas();
        mostrarBoasVindas();



    }

}
