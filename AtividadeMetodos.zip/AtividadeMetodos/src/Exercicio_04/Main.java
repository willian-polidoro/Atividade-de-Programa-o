package Exercicio_04;

public class Main {
    // Método criado:
public static void calcularQuadrado() {

    int resultado = 5;
    System.out.println("Resultado: " + resultado * resultado);
}
    // Método criado:
public static void caucularTriplo(){

    int numero = 5;
    System.out.println("Resultado: " + numero * 3);
}
    public static void main(String[] args) {
    calcularQuadrado();
    caucularTriplo();
    }


}
