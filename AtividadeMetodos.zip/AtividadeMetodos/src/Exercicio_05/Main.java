package Exercicio_05;

import java.util.Scanner;

public class Main {

        public static void main (String[]args){
            Scanner scanner = new Scanner(System.in);
            System.out.print("Digite a primeira nota segundo o Desafio Scanner: ");
            double nota1 = scanner.nextDouble();
            System.out.print("Digite a segunda nota segundo o Desafio Scanner: ");
            double nota2 = scanner.nextDouble();
            double media = calcularMedia(nota1, nota2);
            boolean aprovado = estaAprovado(media);
            mostrarResultado(media, aprovado);
        }
        // Método criado:
        public static double calcularMedia ( double n1, double n2){
            double media= (n1 + n2) / 2;
            return media;
        }
        // Método criado:
        public static boolean estaAprovado ( double situacao){
            return situacao >= 7;
        }
        // Método criado:
        public static void mostrarResultado ( double media, boolean aprovado){
            String situacao = aprovado ? "APROVADO" : "REPROVADO";
            System.out.println("Média: " + media + " / Situação: " + situacao + ".");
        }
    }


    // TODO: crie calcularMedia(double n1, double n2), retornando double.
    // TODO: crie estaAprovado(double media), retornando boolean.
    // TODO: crie mostrarResultado(double media, boolean aprovado), sem retorno.

