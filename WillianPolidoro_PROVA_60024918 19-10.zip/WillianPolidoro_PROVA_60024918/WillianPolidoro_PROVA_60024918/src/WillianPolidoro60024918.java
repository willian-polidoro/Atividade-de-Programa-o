import java.util.Scanner;

public class WillianPolidoro60024918 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int[] numeroDoEleitor = new int[5];
        int[] deputadosFederal = new int[5];
        int[] deputadosEstadual = new int[5];
        int[] senadores = new int[5];
        int[] governadores = new int[5];
        int[] presidentes = new int[5];
        int quantidadeEleitores = 0;

        int opcao = -1;

        while (opcao != 0) {

            System.out.println("\n=== SISTEMA ELEITORAL ===");
            System.out.println("1 - Iniciar votação  ");
            System.out.println("2 - Consultar votos de um eleitor");
            System.out.println("3 - Exibir resultado");
            System.out.println("4 - Mostrar vencedores");
            System.out.println("0 - Encerrar");
            System.out.print("Escolha uma opção: ");

            opcao = sc.nextInt();

            switch (opcao) {
                case 1:


                        System.out.println("Informe o número do Eleitor ");
                        int numeroEleitor = sc.nextInt();

                        boolean controleValido = true;

                        if ((numeroEleitor < 1001 || numeroEleitor > 1005) && numeroEleitor != 60024918) {

                            //VERDADE
                            System.out.println(" Número do Eleitor inválido ");
                            controleValido = false;

                        }

                        if(numeroDoEleitor[0] == numeroEleitor || numeroDoEleitor[1] == numeroEleitor
                                || numeroDoEleitor[2] == numeroEleitor || numeroDoEleitor[3] == numeroEleitor
                                || numeroDoEleitor[4] == numeroEleitor){

                            System.out.println(" Usuario já Votou");
                            controleValido = false;

                        }

                        if( controleValido == true){
                            numeroDoEleitor[quantidadeEleitores] = numeroEleitor;
                        }

                        controleValido = true;

                        do {

                            System.out.println("Solicite o voto para cargo de Federal ");
                            System.out.println("101 = José Bombinha");
                            System.out.println("102 = Ana Silva ");
                            System.out.println("103 = Carlos Lima ");
                            int deputadoFederal = sc.nextInt();

                            if (deputadoFederal >= 101 && deputadoFederal <= 103) {
                                deputadosFederal[quantidadeEleitores] = deputadoFederal;
                                controleValido = true;
                            }else {
                                controleValido = false;
                                System.err.println("Candidato Errado");
                            }

                        }while (controleValido == false);

                    controleValido = true;

                    do {

                        System.out.println("Solicite o voto para cargo de Estadual ");
                        System.out.println("201 = Taffe da Galera ");
                        System.out.println("202 = Rodrigo Pato Depenado");
                        System.out.println("203 = Mariana Costa");
                        int deputadoEstadual = sc.nextInt();

                        if (deputadoEstadual >= 201 && deputadoEstadual <= 203) {
                            deputadosEstadual[quantidadeEleitores] = deputadoEstadual;
                            controleValido = true;
                        }else {
                            controleValido = false;
                            System.err.println("Candidato Errado");
                        }

                    }while (controleValido == false);
                    do {

                        System.out.println("Solicite o voto para cargo de Senador ");
                        System.out.println("301 = Huilson Clone ");
                        System.out.println("302 = Juliana Rocha ");
                        System.out.println("303 = Roberto Martins ");
                        int senador = sc.nextInt();

                        if (senador >= 301 && senador <= 303) {
                            senadores[quantidadeEleitores] = senador;
                            controleValido = true;
                        }else {
                            controleValido = false;
                            System.err.println("Candidato Errado");
                        }

                    }while (controleValido == false);

                    do {

                        System.out.println("Solicite o voto para cargo de Governador ");
                        System.out.println("401 = Patrick Cobra ");
                        System.out.println("402 = Fernanda Souza ");
                        System.out.println("403 = Ricardo Oliveira ");
                        int governador = sc.nextInt();

                        if (governador >= 401 && governador <= 403) {
                            governadores[quantidadeEleitores] = governador;
                            controleValido = true;
                        }else {
                            controleValido = false;
                            System.err.println("Candidato Errado");
                        }

                    }while (controleValido == false);

                    do {

                        System.out.println("Solicite o voto para cargo de Presidente ");
                        System.out.println("501 = Willian Polidoro");
                        System.out.println("502 = Alessandro das Redes ");
                        System.out.println("503 = Lucas Ferreira ");
                        int presidente = sc.nextInt();

                        if (presidente>= 501 && presidente <= 503) {
                            presidentes[quantidadeEleitores] = presidente;
                            controleValido = true;
                        }else {
                            controleValido = false;
                            System.err.println("Candidato Errado");
                        }
                        System.out.println("Eleitor " + numeroEleitor + "  acabou de votar!");
                    }while (controleValido == false);

                    quantidadeEleitores ++;

                    break;
                case 2:
                    System.out.println("Qual eleitor quer consultar os votos?");
                    int eleitorConsulta = sc.nextInt();

                    int posicao = -1;


                    for (int i = 0; i < quantidadeEleitores; i++) {
                        if (numeroDoEleitor[i] == eleitorConsulta) {
                            posicao = i;
                            break;
                        }
                    }


                    if (posicao == -1) {
                        System.err.println("Eleitor nao encontrado!");
                    } else {
                        System.out.println("Votos do eleitor " + eleitorConsulta);

                        System.out.println("Deputado Federal: "
                                + deputadosFederal[posicao]);

                        System.out.println("Deputado Estadual: "
                                + deputadosEstadual[posicao]);

                        System.out.println("Senador: "
                                + senadores[posicao]);

                        System.out.println("Governador: "
                                + governadores[posicao]);

                        System.out.println("Presidente: "
                                + presidentes[posicao]);
                    }

                    break;
                case 3:
                int votosRecebidos = sc.nextInt();
                    System.out.println(" Federal ");
                    System.out.println("101 = José Bombinha ");
                    System.out.println("102 = Ana Silva ");
                    System.out.println("103 = Carlos Lima ");

                    System.out.println(" Estadual ");
                    System.out.println("201 = Taffe da Galera ");
                    System.out.println("202 = Rodrigo Pato Depenado");
                    System.out.println("203 = Mariana Costa");

                    System.out.println(" Senador ");
                    System.out.println("301 = Huilson Clone ");
                    System.out.println("302 = Juliana Rocha ");
                    System.out.println("303 = Roberto Martins ");

                    System.out.println(" Governador ");
                    System.out.println("401 = Patrick Cobra ");
                    System.out.println("402 = Fernanda Souza ");
                    System.out.println("403 = Ricardo Oliveira ");

                    System.out.println(" Presidente ");
                    System.out.println("501 = Willian Polidoro");
                    System.out.println("502 = Alessandro das Redes ");
                    System.out.println("503 = Lucas Ferreira ");

            }
        }
    }}
